import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

@Component({
  selector: 'app-rental-agreement-extensions',
  templateUrl: './rental-agreement-extensions.component.html',
  styleUrls: ['./rental-agreement-extensions.component.scss']
})
export class RentalAgreementExtensionsComponent implements OnInit {
  public rentalAgreements;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  showExtendSuccess() {
    this.toastr.success('Rental agreement extended successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showRejectExtensionSuccess() {
    this.toastr.success('Rental agreement extension rejected successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showCancelSuccess() {
    this.toastr.success('Rental agreement canceled successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
    this.rentalAgreements = await this.service.Get('/rentalAgreement');
    console.log(this.rentalAgreements);
  }

  async extend(){}

  async rejectExtension(){}

  async cancel(){}
}
