import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

@Component({
  selector: 'app-view-client-purchases',
  templateUrl: './view-client-purchases.component.html',
  styleUrls: ['./view-client-purchases.component.scss']
})
export class ViewClientPurchasesComponent implements OnInit {
  public saleAgreements;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  ngOnInit(): void {
  }

  showAcceptSuccess() {
    this.toastr.success('You have accepted your sale agreement', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showDeclineSuccess() {
    this.toastr.success('You have declined your sale agreement', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }
}
