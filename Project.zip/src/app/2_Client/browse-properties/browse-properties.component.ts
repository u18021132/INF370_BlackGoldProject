import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-browse-properties',
  templateUrl: './browse-properties.component.html',
  styleUrls: ['./browse-properties.component.scss']
})
export class BrowsePropertiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
