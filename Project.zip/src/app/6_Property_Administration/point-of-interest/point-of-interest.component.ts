import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';
import { FormGroup, FormControl,FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-point-of-interest',
  templateUrl: './point-of-interest.component.html',
  styleUrls: ['./point-of-interest.component.scss']
})

export class PointOfInterestComponent implements OnInit {
  public pointsOfInterest;
  propertyForm : FormGroup;
  public description : string;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService, private formbulider: FormBuilder) { }

  showAddSuccess() {
    this.toastr.success('Point of interest added successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showUpdateSuccess() {
    this.toastr.success('Point of interest updated successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showDeleteSuccess() {
    this.toastr.success('Point of interest deleted successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
  this.pointsOfInterest = await this.service.Get('/pointOfInterest');
  console.log(this.pointsOfInterest);

  this.propertyForm = this.formbulider.group({ 
    description: ['', [Validators.required, Validators.maxLength(50)]], 
    descriptionInput: ['', [Validators.required, Validators.maxLength(50)]]
  }); 
  }
  get values(): any { return this.propertyForm.value }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }

}
