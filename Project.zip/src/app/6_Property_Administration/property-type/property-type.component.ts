import { Component, OnInit } from '@angular/core';

import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs'; 
import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';

@Component({
  selector: 'app-property-type',
  templateUrl: './property-type.component.html',
  styleUrls: ['./property-type.component.scss']
})

export class PropertyTypeComponent implements OnInit {
  public propertyTypes;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, 
    private toastr: ToastrService) { }

  showAddSuccess() {
    this.toastr.success('Property type added successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showUpdateSuccess() {
    this.toastr.success('Property type updated successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showDeleteSuccess() {
    this.toastr.success('Property type deleted successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
    this.propertyTypes = await this.service.Get('/propertyType');
    console.log(this.propertyTypes);
  }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }

}
