import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';
import { FormGroup, FormControl,FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-other-building-detail',
  templateUrl: './other-building-detail.component.html',
  styleUrls: ['./other-building-detail.component.scss']
})
export class OtherBuildingDetailComponent implements OnInit {
  public otherBuildingDetails;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, 
    private toastr: ToastrService) { }

  showAddSuccess() {
    this.toastr.success('Other building detail added successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showUpdateSuccess() {
    this.toastr.success('Other building detail updated successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showDeleteSuccess() {
    this.toastr.success('Other building detail deleted successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
    this.otherBuildingDetails = await this.service.Get('/otherBuildingDetail');
    console.log(this.otherBuildingDetails);
  }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }
}
