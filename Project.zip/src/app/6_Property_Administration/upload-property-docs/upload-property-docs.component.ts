import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

@Component({
  selector: 'app-upload-property-docs',
  templateUrl: './upload-property-docs.component.html',
  styleUrls: ['./upload-property-docs.component.scss']
})

export class UploadPropertyDocsComponent implements OnInit {
  public propertyDocuments

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  async ngOnInit() {
    this.propertyDocuments = await this.service.Get('/propertyDocument');
    console.log(this.propertyDocuments);
  }

  showUploadSuccess() {
    this.toastr.success('Property document uploaded successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async upload(){

  }

}
