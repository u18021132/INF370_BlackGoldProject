import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';
import { FormGroup, FormControl,FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-market-types',
  templateUrl: './market-types.component.html',
  styleUrls: ['./market-types.component.scss']
})

export class MarketTypesComponent implements OnInit {
  public marketTypes;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, 
    private toastr: ToastrService) { }

  showAddSuccess() {
    this.toastr.success('Market type added successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showUpdateSuccess() {
    this.toastr.success('Market type updated successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showDeleteSuccess() {
    this.toastr.success('Market type deleted successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
    this.marketTypes = await this.service.Get('/marketType');
    console.log(this.marketTypes);
  }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }
}
