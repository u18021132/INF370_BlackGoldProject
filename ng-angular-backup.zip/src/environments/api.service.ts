import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
url = 'https://localhost:44373/api';
  constructor(private http: HttpClient) { }
  headers = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }


  //Read
  public async Get(endpoint: string){
    let response = await this.http.get(`${this.url}${endpoint}`).toPromise();
    return response;
  }



}
