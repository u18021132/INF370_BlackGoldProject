import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inspections',
  templateUrl: './inspections.component.html',
  styleUrls: ['./inspections.component.scss']
})
export class InspectionsComponent implements OnInit {
  constructor() { }
  counter:any;
  ngOnInit() {
  }

}
