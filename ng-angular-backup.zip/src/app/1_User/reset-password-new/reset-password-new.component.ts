import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reset-password-new',
  templateUrl: './reset-password-new.component.html',
  styleUrls: ['./reset-password-new.component.scss']
})
export class ResetPasswordNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
