import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-valuations',
  templateUrl: './valuations.component.html',
  styleUrls: ['./valuations.component.scss']
})
export class ValuationsComponent implements OnInit {

  constructor() { }

  async ngOnInit() {

  }



}
