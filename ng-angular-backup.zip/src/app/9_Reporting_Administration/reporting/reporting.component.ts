import { Component, OnInit } from '@angular/core';

import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reporting',
  templateUrl: './reporting.component.html',
  styleUrls: ['./reporting.component.scss']
})
export class ReportingComponent implements OnInit {

  constructor() { }

  async ngOnInit() {
  }

  async add(){

  }

}
