import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suburbs',
  templateUrl: './suburbs.component.html',
  styleUrls: ['./suburbs.component.scss']
})
export class SuburbsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
