import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provinces',
  templateUrl: './provinces.component.html',
  styleUrls: ['./provinces.component.scss']
})
export class ProvincesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
