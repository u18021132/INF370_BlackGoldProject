import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-client',
  templateUrl: './register-client.component.html',
  styleUrls: ['./register-client.component.scss']
})
export class RegisterClientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
