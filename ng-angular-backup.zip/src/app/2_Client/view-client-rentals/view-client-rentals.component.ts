import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-client-rentals',
  templateUrl: './view-client-rentals.component.html',
  styleUrls: ['./view-client-rentals.component.scss']
})
export class ViewClientRentalsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
