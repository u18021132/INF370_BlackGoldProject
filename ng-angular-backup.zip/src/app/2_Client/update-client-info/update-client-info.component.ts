import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-client-info',
  templateUrl: './update-client-info.component.html',
  styleUrls: ['./update-client-info.component.scss']
})
export class UpdateClientInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
