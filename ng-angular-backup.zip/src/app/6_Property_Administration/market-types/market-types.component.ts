import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-types',
  templateUrl: './market-types.component.html',
  styleUrls: ['./market-types.component.scss']
})
export class MarketTypesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
