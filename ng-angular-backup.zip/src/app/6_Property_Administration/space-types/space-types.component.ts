import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-space-types',
  templateUrl: './space-types.component.html',
  styleUrls: ['./space-types.component.scss']
})
export class SpaceTypesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
