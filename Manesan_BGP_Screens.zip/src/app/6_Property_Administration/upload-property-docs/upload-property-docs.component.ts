import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-property-docs',
  templateUrl: './upload-property-docs.component.html',
  styleUrls: ['./upload-property-docs.component.scss']
})
export class UploadPropertyDocsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
