import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-point-of-interest',
  templateUrl: './point-of-interest.component.html',
  styleUrls: ['./point-of-interest.component.scss']
})
export class PointOfInterestComponent implements OnInit {
public pointsofinterest;

  constructor(private service: ApiService, private http: HttpClient, private router: Router) { }

  async ngOnInit() {
  this.pointsofinterest = await this.service.Get('/pointofinterest');
  console.log(this.pointsofinterest);
  }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }

}
