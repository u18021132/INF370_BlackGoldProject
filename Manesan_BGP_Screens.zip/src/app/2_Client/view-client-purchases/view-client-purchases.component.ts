import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-client-purchases',
  templateUrl: './view-client-purchases.component.html',
  styleUrls: ['./view-client-purchases.component.scss']
})
export class ViewClientPurchasesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
