import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-agent',
  templateUrl: './contact-agent.component.html',
  styleUrls: ['./contact-agent.component.scss']
})
export class ContactAgentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
