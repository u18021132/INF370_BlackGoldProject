import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {AboutUsComponent} from './about-us/about-us.component';
import {AdminPortalComponent} from './admin-portal/admin-portal.component';

import {LoginComponent} from './1_User/login/login.component';
import {ResetPasswordComponent} from './1_User/reset-password-otp/reset-password.component';
import {ResetPasswordNewComponent} from './1_User/reset-password-new/reset-password-new.component';

import {ContactAgentComponent} from './2_Client/contact-agent/contact-agent.component';
import {BrowsePropertiesComponent} from './2_Client/browse-properties/browse-properties.component';
import {RegisterClientComponent} from './2_Client/register-client/register-client.component';
import {UpdateClientInfoComponent} from './2_Client/update-client-info/update-client-info.component';
import {ViewPropertyComponent} from './2_Client/view-property/view-property.component';
import {ViewClientRentalsComponent} from './2_Client/view-client-rentals/view-client-rentals.component';
import {ViewClientPurchasesComponent} from './2_Client/view-client-purchases/view-client-purchases.component';
import {SearchPropertiesComponent} from './2_Client/search-properties/search-properties.component';

import {InspectionsComponent} from './4_Inspection_Administration/inspections/inspections.component'

import {ValuationsComponent} from './5_Valuation_Administration/valuations/valuations.component';

import {PointOfInterestComponent} from './6_Property_Administration/point-of-interest/point-of-interest.component';
import {UploadPropertyDocsComponent} from './6_Property_Administration/upload-property-docs/upload-property-docs.component';


const routes: Routes = [
  {path: '', component: SearchPropertiesComponent },
  {path: 'contactagent', component: ContactAgentComponent },
  {path: 'browse', component: BrowsePropertiesComponent },
  {path: 'login', component: LoginComponent },
  {path: 'pointofinterest', component: PointOfInterestComponent },
  {path: 'adminportal', component: AdminPortalComponent },
  {path: 'register', component: RegisterClientComponent },
  {path: 'resetpassword', component: ResetPasswordComponent },
  {path: 'valuations', component: ValuationsComponent },
  {path: 'propertydocs', component: UploadPropertyDocsComponent },
  {path: 'resetpasswordnew', component: ResetPasswordNewComponent },
  {path: 'updateclient', component: UpdateClientInfoComponent },
  {path: 'viewproperty', component: ViewPropertyComponent },
  {path: 'client-rentals', component: ViewClientRentalsComponent },
  {path: 'client-purchases', component: ViewClientPurchasesComponent },
  {path: 'search-properties', component: SearchPropertiesComponent },
  {path: 'inspections', component: InspectionsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
