//search bar
function searchCards() {
  var input, filter, cards, cardContainer, h5, title, i;
  input = document.getElementById("myFilter");
  filter = input.value.toUpperCase();
  cardContainer = document.getElementById("myCards");
  cards = cardContainer.getElementsByClassName("card");
  for (i = 0; i < cards.length; i++) {
      title = cards[i].querySelector(".card-body h5.card-title ");
      if (title.innerText.toUpperCase().indexOf(filter) > -1) {
          cards[i].style.display = "";
      } else {
          cards[i].style.display = "none";
      }
  }
}


$(document).ready(function () {
  if (!$.browser.webkit) {
      $('.wrapper').html('<p>Sorry! Non webkit users. :(</p>');
  }
});


//Browse properties filters:
function filterDefault(){
  document.getElementById("filterCategory").innerHTML = 'Default';
}
function filterLTH(){
  document.getElementById("filterCategory").innerHTML = 'Low to High';
}
function filterHTL(){
  document.getElementById("filterCategory").innerHTML = 'High to Low';
}
function filterRecent(){
  document.getElementById("filterCategory").innerHTML = 'Most Recent';
}
function filterType(){
  document.getElementById("filterCategory").innerHTML = 'Property Type';
}


//back button
function goBack() {
  window.history.back();
}



function hideDiv(){
  var x = document.getElementById("moreOptions");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";

  }
}




function editInspection() {
  //edit header text
  document.getElementById("title").innerHTML = "Capture Inspection";

  //hide edit button
  document.getElementById("edit").style.display = "none";

  //make upload doc button visible
  document.getElementById("uploadButton").display ==="block" ;
  uploadButton.style.visibility = "visible";

  //make OK button visible
  document.getElementById("OKButton").display ==="block" ;
  OKButton.style.visibility = "visible";

  //make labels visible
  document.getElementById("label1").display ==="block" ;
  label1.style.visibility = "visible";

  //enable input fields
  document.getElementById("input1").disabled = false;
  document.getElementById("input2").disabled = false;
  document.getElementById("input3").disabled = false;
  document.getElementById("input4").disabled = false;
  document.getElementById("input5").disabled = false;
}

function editPointOfInterest(){
  //edit header text
  document.getElementById("title").innerHTML = "Update Point of Interest";

  //hide edit button
  document.getElementById("edit").style.display = "none";


  //make OK button visible
  document.getElementById("OKButton").display ==="block" ;
  OKButton.style.visibility = "visible";


  //enable input fields
  document.getElementById("description").disabled = false;
  document.getElementById("type").disabled = false;
  document.getElementById("suburb").disabled = false;


}

function editValuation() {
  //edit header text
  document.getElementById("title").innerHTML = "Capture Valuation";

  //hide edit button
  document.getElementById("edit").style.display = "none";

  //make upload doc button visible
  document.getElementById("uploadButton").display ==="block" ;
  uploadButton.style.visibility = "visible";

  //make OK button visible
  document.getElementById("OKButton").style.visibility = "visible" ;


  //make labels visible
  document.getElementById("label1").display ==="block" ;
  label1.style.visibility = "visible";

  //enable input fields
  document.getElementById("input2").disabled = false;
  document.getElementById("input3").disabled = false;
  document.getElementById("input4").disabled = false;

  document.getElementById("input6").disabled = false;

  document.getElementById("prompt").innerHTML = "Please provide the updated valuation details";
  document.getElementById("downloadDocument").style.display = "none" ;
}

function editRentalAgreement() {
  //edit header text
  document.getElementById("title").innerHTML = "Maintain Rental Agreement";

  //hide edit button
  document.getElementById("edit").style.display = "none";


  //make OK button visible
  document.getElementById("OKButton").display ==="block" ;
  OKButton.style.visibility = "visible";

  //make labels visible
  document.getElementById("label1").display ==="block" ;
  label1.style.visibility = "visible";
  document.getElementById("label2").display ==="block" ;
  label2.style.visibility = "visible";
  document.getElementById("label3").display ==="block" ;
  label3.style.visibility = "visible";

  //make upload button visible
  document.getElementById("uploadButton1").display ==="block" ;
  uploadButton1.style.visibility = "visible";
}

//registration radio button options for id or passport
function southAfrican(){
  document.getElementById("idnumber").placeholder = "ID Number";
  document.getElementById("idnumber").id = "idnumber";
}
function notSouthAfrican(){
  document.getElementById("idnumber").placeholder = "Passport Number";
  document.getElementById("idnumber").id = "passport";
}

//convert address into google maps link
function addressLink(){
  $("address").each(function(){
    var embed ="<iframe width='500' height='100' frameborder='0' scrolling='no'  marginheight='0' marginwidth='0'   src='https://maps.google.com/maps?&amp;q="+ encodeURIComponent( $(this).text() ) +"&amp;output=embed'></iframe>";
                                $(this).html(embed);
   });
};


