import { Component, OnInit } from '@angular/core';

import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss']
})
export class ClientComponent implements OnInit {
  constructor() { }

  async ngOnInit() {
  }

  async upload(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }
}
