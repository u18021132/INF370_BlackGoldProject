import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClientComponent } from './7_Client/client/client.component';
import { EmployeeComponent } from './8_Employee/employee/employee.component';
import { EmployeeTypeComponent } from './8_Employee/employee-type/employee-type.component';
import { ActionComponent } from './8_Employee/action/action.component';
import { ReportingComponent } from './9_Reporting/reporting/reporting.component';
import { FeatureComponent } from './6_Property/feature/feature.component';
import { OtherBuildingDetailComponent } from './6_Property/other-building-detail/other-building-detail.component';

@NgModule({
  declarations: [
    AppComponent,
    ClientComponent,
    EmployeeComponent,
    EmployeeTypeComponent,
    ActionComponent,
    ReportingComponent,
    FeatureComponent,
    OtherBuildingDetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
