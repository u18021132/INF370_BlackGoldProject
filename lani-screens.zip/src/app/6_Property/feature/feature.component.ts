import { Component, OnInit } from '@angular/core';

import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-feature',
  templateUrl: './feature.component.html',
  styleUrls: ['./feature.component.scss']
})
export class FeatureComponent implements OnInit {
  constructor() { }

  async ngOnInit() {
  }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }

}
