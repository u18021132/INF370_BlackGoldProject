import { Component, OnInit } from '@angular/core';

import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-other-building-detail',
  templateUrl: './other-building-detail.component.html',
  styleUrls: ['./other-building-detail.component.scss']
})
export class OtherBuildingDetailComponent implements OnInit {
  constructor() { }

  async ngOnInit() {
  }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }
}
