import { Component, OnInit } from '@angular/core';

import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit {
  constructor() { }

  async ngOnInit() {
  }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }

  async upload(/*id*/){

  }
}
