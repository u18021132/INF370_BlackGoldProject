import { Component, OnInit } from '@angular/core';

import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-action',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.scss']
})
export class ActionComponent implements OnInit {
  constructor() { }

  async ngOnInit() {
  }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }

}
