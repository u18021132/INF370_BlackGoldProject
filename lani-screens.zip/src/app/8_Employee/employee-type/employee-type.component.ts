import { Component, OnInit } from '@angular/core';

import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-type',
  templateUrl: './employee-type.component.html',
  styleUrls: ['./employee-type.component.scss']
})
export class EmployeeTypeComponent implements OnInit {
  constructor() { }

  async ngOnInit() {
  }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }
}
