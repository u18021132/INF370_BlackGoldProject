function searchCards() {
  var input, filter, cards, cardContainer, h5, title, i;
  input = document.getElementById("myFilter");
  filter = input.value.toUpperCase();
  cardContainer = document.getElementById("myCards");
  cards = cardContainer.getElementsByClassName("card");
  for (i = 0; i < cards.length; i++) {
      title = cards[i].querySelector(".card-body h5.card-title ");
      if (title.innerText.toUpperCase().indexOf(filter) > -1) {
          cards[i].style.display = "";
      } else {
          cards[i].style.display = "none";
      }
  }
}

$(document).ready(function () {
  if (!$.browser.webkit) {
      $('.wrapper').html('<p>Sorry! Non webkit users. :(</p>');
  }
});


function goBack() {
  window.history.back();
}


function hideDiv(){
  var x = document.getElementById("moreOptions");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";

  }
}

// Grouped functionality for single-attribute CRUDs
function editSingleAttributeCRUD(objectName) {

  // edit header text
  document.getElementById("title").innerHTML = "Update " + objectName;
  
  //hide control
  document.getElementById("edit").style.display = "none";  

  //show control
  document.getElementById("OKButton").style.visibility = "visible";  
  document.getElementById("prompt").style.display = "block"; 

  //enable input field
  document.getElementById("descriptionInput").disabled = false;  
}

// Employee
function editEmployee() {
    //edit header text
    document.getElementById("title").innerHTML = "Update Employee";

    //hide edit button
    document.getElementById("edit").style.display = "none";
  
    //make OK button visible
    document.getElementById("OKButton").display ==="block" ;
    OKButton.style.visibility = "visible";
  
    //enable input fields
    document.getElementById("nameInput").disabled = false;
    document.getElementById("surnameInput").disabled = false;
    document.getElementById("contactNumberInput").disabled = false;
    document.getElementById("alternativeContactNumberInput").disabled = false;
    document.getElementById("emailInput").disabled = false;
    document.getElementById("idNumberInput").disabled = false;
    document.getElementById("passportNumberInput").disabled = false;
    document.getElementById("addressInput").disabled = false;
    document.getElementById("passwordInput").disabled = false;
    document.getElementById("bankingDetailsInput").disabled = false;
    document.getElementById("dateEmployed").disabled = false;
    document.getElementById("remunerationInput").disabled = false;
    document.getElementById("typeSelect").disabled = false;
    document.getElementById("actionSelect").disabled = false;

  //display the prompt message
  document.getElementById("prompt").style.display = "block";

  document.getElementById("multipleFuncButton").display === "block";

}

//select multiple actions for the employee
function multipleFunc() {
  document.getElementById("actionSelect").multiple = true;
  document.getElementById("type").multiple = true;
}

function southAfrican(){
  document.getElementById("idnumber").placeholder = "ID Number";
  document.getElementById("idnumber").id = "idnumber";
}
function notSouthAfrican(){
  document.getElementById("idnumber").placeholder = "Passport Number";
  document.getElementById("idnumber").id = "passport";
}