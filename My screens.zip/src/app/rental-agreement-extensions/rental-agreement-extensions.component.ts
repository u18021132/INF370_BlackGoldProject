import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rental-agreement-extensions',
  templateUrl: './rental-agreement-extensions.component.html',
  styleUrls: ['./rental-agreement-extensions.component.scss']
})
export class RentalAgreementExtensionsComponent implements OnInit {

  constructor() {}

  async ngOnInit() {}

  async add(){}

  async delete(/*id*/){}

  async update(/*id*/){}
}
