import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PropertyOwnerComponent } from './property-owner/property-owner.component';
import{PropertyComponent}from './property/property.component';
import { RentalApplicationsComponent } from './rental-applications/rental-applications.component';
import { AgentPurchaseOffersComponent } from './agent-purchase-offers/agent-purchase-offers.component';
import { RentalAgreementExtensionsComponent } from './rental-agreement-extensions/rental-agreement-extensions.component';
import { CancelRentalAgreementComponent } from './cancel-rental-agreement/cancel-rental-agreement.component';
import { AgentSaleAgreementsComponent } from './agent-sale-agreements/agent-sale-agreements.component';
import { PropertytypeComponent } from './property-type/property-type.component';
import { PropertydefectComponent } from './property-defect/property-defect.component';
import { PropertyspaceComponent } from './property-space/property-space.component';


const routes: Routes = [ 
{path: 'property', component: PropertyComponent },
{path: 'propertyowner', component: PropertyOwnerComponent },
{path: 'rentalapplications', component: RentalApplicationsComponent },
{path: 'agentpurchases', component: AgentPurchaseOffersComponent },
{path: 'agentrentalagreements', component: RentalAgreementExtensionsComponent },
{path: 'agentsaleagreement', component: AgentSaleAgreementsComponent },
{path: 'propertytype', component: PropertytypeComponent },
{path: 'propertydefect', component: PropertydefectComponent },
{path: 'propertyspace', component: PropertyspaceComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
