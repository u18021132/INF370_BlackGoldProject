import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-sale-agreements',
  templateUrl: './agent-sale-agreements.component.html',
  styleUrls: ['./agent-sale-agreements.component.scss']
})
export class AgentSaleAgreementsComponent implements OnInit {

  constructor() {}

  async ngOnInit() {}

  async add(){}

  async delete(/*id*/){}

  async update(/*id*/){}

}
