import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//google maps import
//import { AgmCoreModule } from '@agm/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PropertyComponent } from './property/property.component';
import { PropertyOwnerComponent } from './property-owner/property-owner.component';
import { RentalApplicationsComponent } from './rental-applications/rental-applications.component';
import { AgentPurchaseOffersComponent } from './agent-purchase-offers/agent-purchase-offers.component';
import { RentalAgreementExtensionsComponent } from './rental-agreement-extensions/rental-agreement-extensions.component';
import { CancelRentalAgreementComponent } from './cancel-rental-agreement/cancel-rental-agreement.component';
import { AgentSaleAgreementsComponent } from './agent-sale-agreements/agent-sale-agreements.component';
import { PropertytypeComponent } from './property-type/property-type.component';
import { PropertydefectComponent } from './property-defect/property-defect.component';
import { PropertyspaceComponent } from './property-space/property-space.component';

@NgModule({
  declarations: [
    AppComponent,
    PropertyComponent,
    PropertyOwnerComponent,
    RentalApplicationsComponent,
    AgentPurchaseOffersComponent,
    RentalAgreementExtensionsComponent,
    CancelRentalAgreementComponent,
    AgentSaleAgreementsComponent,
    PropertytypeComponent,
    PropertydefectComponent,
    PropertyspaceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
     //google  api key
     //AgmCoreModule.forRoot({
      //apiKey: 'AIzaSyAzSnXXXXXXXXXXXXXXXXXSZGGWU',
      //libraries: ['places']
  ],
  providers: [],
  bootstrap: [AppComponent],

})
export class AppModule { }
