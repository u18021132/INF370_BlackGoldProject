import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-property-space',
  templateUrl: './property-space.component.html',
  styleUrls: ['./property-space.component.scss']
})
export class PropertyspaceComponent implements OnInit {

  constructor() {}

  async ngOnInit() {}

  async add(){}

  async delete(/*id*/){}

  async update(/*id*/){}

}
