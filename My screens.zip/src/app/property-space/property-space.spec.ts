import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignInspectorToInspectionsComponent } from './property-space.component';

describe('AssignInspectorToInspectionsComponent', () => {
  let component: AssignInspectorToInspectionsComponent;
  let fixture: ComponentFixture<AssignInspectorToInspectionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignInspectorToInspectionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignInspectorToInspectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
