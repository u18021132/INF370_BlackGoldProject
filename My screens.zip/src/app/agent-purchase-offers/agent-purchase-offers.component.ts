import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-purchase-offers',
  templateUrl: './agent-purchase-offers.component.html',
  styleUrls: ['./agent-purchase-offers.component.scss']
})
export class AgentPurchaseOffersComponent implements OnInit {

  constructor() {}

  async ngOnInit() {}

  async add(){}

  async delete(/*id*/){}

  async update(/*id*/){}

}
