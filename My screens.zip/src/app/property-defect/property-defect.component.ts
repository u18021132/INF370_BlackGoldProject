import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-property-defect',
  templateUrl: './property-defect.component.html',
  styleUrls: ['./property-defect.component.scss']
})
export class PropertydefectComponent implements OnInit {

  constructor() {}

  async ngOnInit() {}

  async add(){}

  async delete(/*id*/){}

  async update(/*id*/){}


}
