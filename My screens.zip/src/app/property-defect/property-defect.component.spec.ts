import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignValuerToValuationsComponent } from './property-defect.component';

describe('AssignValuerToValuationsComponent', () => {
  let component: AssignValuerToValuationsComponent;
  let fixture: ComponentFixture<AssignValuerToValuationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignValuerToValuationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignValuerToValuationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
