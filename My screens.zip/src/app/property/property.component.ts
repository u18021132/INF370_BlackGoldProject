import { Component, OnInit } from '@angular/core';

//import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-property',
  templateUrl: './property.component.html',
  styleUrls: ['./property.component.scss']
})
export class PropertyComponent implements OnInit {

  constructor() {}

  async ngOnInit() {}

  async add(){}

  async delete(/*id*/){}

  async update(/*id*/){}

}
