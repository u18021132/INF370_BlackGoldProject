import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rental-applications',
  templateUrl: './rental-applications.component.html',
  styleUrls: ['./rental-applications.component.scss']
})
export class RentalApplicationsComponent implements OnInit {

  constructor() {}

  async ngOnInit() {}

  async add(){}

  async delete(/*id*/){}

  async update(/*id*/){}


}
