import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-property-type',
  templateUrl: './property-type.component.html',
  styleUrls: ['./property-type.component.scss']
})
export class PropertytypeComponent implements OnInit {

  constructor() {}

  async ngOnInit() {}

  async add(){}

  async delete(/*id*/){}

  async update(/*id*/){}

}
