import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-rental-agreement',
  templateUrl: './cancel-rental-agreement.component.html',
  styleUrls: ['./cancel-rental-agreement.component.scss']
})
export class CancelRentalAgreementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
