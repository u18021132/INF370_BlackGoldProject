import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelRentalAgreementComponent } from './cancel-rental-agreement.component';

describe('CancelRentalAgreementComponent', () => {
  let component: CancelRentalAgreementComponent;
  let fixture: ComponentFixture<CancelRentalAgreementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CancelRentalAgreementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CancelRentalAgreementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
