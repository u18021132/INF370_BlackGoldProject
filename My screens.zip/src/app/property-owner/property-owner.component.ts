import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-property-owner',
  templateUrl: './property-owner.component.html',
  styleUrls: ['./property-owner.component.scss']
})
export class PropertyOwnerComponent implements OnInit {

  constructor() {}

  async ngOnInit() {}

  async add(){}

  async delete(/*id*/){}

  async update(/*id*/){}


}
