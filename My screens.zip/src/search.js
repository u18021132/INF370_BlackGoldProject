//search bar
function searchCards() {
  var input, filter, cards, cardContainer, h5, title, i;
  input = document.getElementById("myFilter");
  filter = input.value.toUpperCase();
  cardContainer = document.getElementById("myCards");
  cards = cardContainer.getElementsByClassName("card");
  for (i = 0; i < cards.length; i++) {
      title = cards[i].querySelector(".card-body h5.card-title ");
      if (title.innerText.toUpperCase().indexOf(filter) > -1) {
          cards[i].style.display = "";
      } else {
          cards[i].style.display = "none";
      }
  }
}


$(document).ready(function () {
  if (!$.browser.webkit) {
      $('.wrapper').html('<p>Sorry! Non webkit users. :(</p>');
  }
});



function hideDiv(){
  var x = document.getElementById("moreOptions");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";

  }
}

function editPropertyOwner() {
  //edit header text
  document.getElementById("title").innerHTML = "Edit Property Owner";

  //hide edit button
  document.getElementById("editPropertyOwner").style.display = "none";

  //make OK button visible
  document.getElementById("OKButton").style.visibility = "visible";

  //enable input fields
  document.getElementById("name").disabled = false;
  document.getElementById("surname").disabled = false;
  document.getElementById("email").disabled = false;
  document.getElementById("idnumber").disabled = false;
  document.getElementById("address").disabled = false;
  document.getElementById("contact").disabled = false;
  document.getElementById("altcontact").disabled = false;
}

function editProperty() {
  //edit header text
  document.getElementById("title").innerHTML = "Edit Property";

  //hide edit button
  document.getElementById("editProperty").style.display = "none";


  //make OK button visible
  document.getElementById("OKButton").style.visibility = "visible";


  //enable input fields
  document.getElementById("markettype").disabled = false;
  document.getElementById("propertytype").disabled = false;
  document.getElementById("suburb").disabled = false;
  document.getElementById("mandatetype").disabled = false;
  document.getElementById("mandatedate").disabled = false;
  document.getElementById("city").disabled = false;
  document.getElementById("province").disabled = false;
  document.getElementById("name").disabled = false;
  document.getElementById("surname").disabled = false;
  document.getElementById("ID").disabled = false;
  document.getElementById("altnum").disabled = false;
  document.getElementById("num").disabled = false;
  document.getElementById("address").disabled = false;
  document.getElementById("bedrooms").disabled = false;
  document.getElementById("accept").disabled = false;
  document.getElementById("bathrooms").disabled = false;
  document.getElementById("email").disabled = false;
  document.getElementById("price").disabled = false;
  document.getElementById("email").disabled = false;

}

function editDefect() {
  //edit header text
  document.getElementById("title").innerHTML = "Edit Defect";

  //hide edit button
  document.getElementById("editDefect").style.display = "none";

  //make OK button visible
  document.getElementById("OKButton").style.visibility = "visible";

  //enable input fields
  document.getElementById("Defectdescription").disabled = false;
}

function editSpace() {
  //edit header text
  document.getElementById("title").innerHTML = "Edit Space";

  //hide edit button
  document.getElementById("editSpace").style.display = "none";

  //make OK button visible
  document.getElementById("OKButton").style.visibility = "visible";

  //enable input fields
  document.getElementById("Spacedescription").disabled = false;
}

function editPropertyType() {
  //edit header text
  document.getElementById("title").innerHTML = "Edit Property Type";

  //hide edit button
  document.getElementById("editPropertyType").style.display = "none";

  //make OK button visible
  document.getElementById("OKButton").style.visibility = "visible";

  //enable input fields
  document.getElementById("Propertytypedescription").disabled = false;
}

//registration radio button options for id or passport
function southAfrican(){
   //make visible
   document.getElementById("idnum").style.visibility = "visible";
   document.getElementById("idnumber").style.visibility = "visible";
   document.getElementById("passnum").style.visibility = "hidden";
   document.getElementById("passnumber").style.visibility = "hidden";
}

function notSouthAfrican(){
   //make visible
   document.getElementById("passnum").style.visibility = "visible";
   document.getElementById("passnumber").style.visibility = "visible";
   document.getElementById("idnum").style.visibility = "hidden";
   document.getElementById("idnumber").style.visibility = "hidden";
}
