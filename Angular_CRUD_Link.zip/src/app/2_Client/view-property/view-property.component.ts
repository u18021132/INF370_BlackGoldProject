import { Component, OnInit } from '@angular/core';

import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs'; 

@Component({
  selector: 'app-view-property',
  templateUrl: './view-property.component.html',
  styleUrls: ['./view-property.component.scss']
})
export class ViewPropertyComponent implements OnInit {
  public rentalApplications;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  showRentApplySuccess() {
    this.toastr.success('You have successfully applied to rent this property', "", {
      timeOut: 1500,
    });
    setTimeout(location.reload.bind(location), 1500);
  }

  showPurchaseApplySuccess() {
    this.toastr.success('You have successfully made a purchase offer for this property', "", {
      timeOut: 1500,
    });
    setTimeout(location.reload.bind(location), 1500);
  }
  
  async ngOnInit() {
    this.rentalApplications = await this.service.Get('/rentalApplication');
    console.log(this.rentalApplications);
  }

  async applyRent(){

  }

  async applyPurchase(){

  }

}
