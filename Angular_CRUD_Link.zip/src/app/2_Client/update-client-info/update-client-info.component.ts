import { Component, OnInit } from '@angular/core';

import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs'; 


@Component({
  selector: 'app-update-client-info',
  templateUrl: './update-client-info.component.html',
  styleUrls: ['./update-client-info.component.scss']
})
export class UpdateClientInfoComponent implements OnInit {
  public clients;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  showUpdateSuccess() {
    this.toastr.success('Your profile has been updated successfully!', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showUploadSuccess() {
    this.toastr.success('Document uploaded successfully', "", {
      timeOut: 2000,
    });
    setTimeout(location.reload.bind(location), 2000);
  }

  async ngOnInit() {
    this.clients = await this.service.Get('/client');
    console.log(this.clients);
  }

  async update(/*id*/){

  }

  async upload(){

  }

}
