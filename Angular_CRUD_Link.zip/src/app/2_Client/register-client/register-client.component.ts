import { Component, OnInit } from '@angular/core';

import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

import {FormGroup,FormBuilder, Validators} from '@angular/forms'

@Component({
  selector: 'app-register-client',
  templateUrl: './register-client.component.html',
  styleUrls: ['./register-client.component.scss']
})
export class RegisterClientComponent implements OnInit {
  registrationForm:FormGroup;
  public clients;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService , private fb:FormBuilder) { }

  showRegisterSuccess() {
    this.toastr.success('You are successfully registered', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
    this.clients = await this.service.Get('/client');
    console.log(this.clients);

   // this.registrationForm = this.fb.group({
    //  name:['',[Validators.required]],
     // surname:[''],
     // email:['']
   // })
  }

  async register(){

  }

}
