import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-properties',
  templateUrl: './search-properties.component.html',
  styleUrls: ['./search-properties.component.scss']
})
export class SearchPropertiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
