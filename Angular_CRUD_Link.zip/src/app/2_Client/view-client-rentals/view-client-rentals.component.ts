import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

@Component({
  selector: 'app-view-client-rentals',
  templateUrl: './view-client-rentals.component.html',
  styleUrls: ['./view-client-rentals.component.scss']
})
export class ViewClientRentalsComponent implements OnInit {
  public rentalAgreements;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  showTerminationNoticeSuccess() {
    this.toastr.success('You have submitted your notice of rental agreement termination', "", {
      timeOut: 2000,
    });
    setTimeout(location.reload.bind(location), 2000);
  }

  showAgreementExtensionSuccess() {
    this.toastr.success('You have submitted your rental agreement extension request', "", {
      timeOut: 2000,
    });
    setTimeout(location.reload.bind(location), 2000);
  }

  async ngOnInit() {
    this.rentalAgreements = await this.service.Get('/rentalAgreement');
    console.log(this.rentalAgreements);
  }

  async submit(){

  }

}
