import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

@Component({
  selector: 'app-contact-agent',
  templateUrl: './contact-agent.component.html',
  styleUrls: ['./contact-agent.component.scss']
})

export class ContactAgentComponent implements OnInit {

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  ngOnInit(): void {
  }

  showMessageSentSuccess() {
    this.toastr.success('Your message has been delivered. Keep an eye on your email for our response', "", {
      timeOut: 4000,
    });
    setTimeout(location.reload.bind(location), 4000);
    this.router.navigateByUrl('');
  }

}
