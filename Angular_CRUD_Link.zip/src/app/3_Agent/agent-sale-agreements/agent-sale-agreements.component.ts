import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

@Component({
  selector: 'app-agent-sale-agreements',
  templateUrl: './agent-sale-agreements.component.html',
  styleUrls: ['./agent-sale-agreements.component.scss']
})
export class AgentSaleAgreementsComponent implements OnInit {
  public saleAgreements;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  showAddSuccess() {
    this.toastr.success('City added successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showUpdateSuccess() {
    this.toastr.success('City updated successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
    this.saleAgreements = await this.service.Get('/saleAgreement');
    console.log(this.saleAgreements);
  }

  async add(){

  }

}
