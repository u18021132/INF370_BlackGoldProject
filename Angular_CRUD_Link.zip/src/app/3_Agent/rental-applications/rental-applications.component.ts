import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

@Component({
  selector: 'app-rental-applications',
  templateUrl: './rental-applications.component.html',
  styleUrls: ['./rental-applications.component.scss']
})
export class RentalApplicationsComponent implements OnInit {
  public rentalApplications;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  showAcceptSuccess() {
    this.toastr.success('Rental application accepted successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showRejectSuccess() {
    this.toastr.success('Rental application rejected successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
    this.rentalApplications = await this.service.Get('/rentalApplication');
    console.log(this.rentalApplications);
  }

  async accept(){}

  async reject(){}

}
