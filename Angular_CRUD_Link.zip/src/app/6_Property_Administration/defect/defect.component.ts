import { Component, OnInit } from '@angular/core';

import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

@Component({
  selector: 'app-defect',
  templateUrl: './defect.component.html',
  styleUrls: ['./defect.component.scss']
})
export class DefectComponent implements OnInit {
  public defects; //holds list to populate cards
  public showViewModal: boolean; //bool for view modal
  public token: any; //holds user token

  //Define all the variables to be used
  public defectid: any;
  public descriptionInput: any;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  showAddSuccess() {
    this.toastr.success('Defect added successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showUpdateSuccess() {
    this.toastr.success('Defect updated successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showDeleteSuccess() {
    this.toastr.success('Defect deleted successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
      this.token ={"token" : localStorage.getItem("37y7ffheu73")}
      //console.log(this.token.token);
      this.defects = await this.service.Get('/defect?token=' + this.token.token);
      //console.log(this.defects);
  }

  async view(id){
    this.token ={"token" : localStorage.getItem("37y7ffheu73")}
    //console.log(id);
    let defect = await this.service.Get('/defect?token=' + this.token.token + '&id='+ id) as any;
    //console.log(defect);
    this.descriptionInput = defect.DEFECTDESCRIPTION;
    this.defectid = defect.DEFECTID;
    this.showViewModal = true;
    //console.log(this.descriptionInput);
  }

  async update(id){
    this.token ={"token" : localStorage.getItem("37y7ffheu73")}
    //console.log(id);
    await this.service.Patch(`/defect?token=${this.token.token}&id=${id}&description=${this.descriptionInput}`);
    this.showUpdateSuccess();
  }

  async add(){
    this.token ={"token" : localStorage.getItem("37y7ffheu73")}
    //console.log(this.descriptionInput);
    await this.service.Post(`/defect?token=${this.token.token}&description=${this.descriptionInput}`);
    this.showAddSuccess();
  }

  async deleteBinding(id){
    this.token ={"token" : localStorage.getItem("37y7ffheu73")}
    let defect = await this.service.Get('/defect?token=' + this.token.token + '&id='+ id) as any;
    this.descriptionInput = defect.DEFECTDESCRIPTION;
    this.defectid = defect.DEFECTID;
    //console.log(this.descriptionInput);
  }

  async delete(id){
    this.token ={"token" : localStorage.getItem("37y7ffheu73")}
    this.service.Delete('/defect?token=' + this.token.token + '&id='+ id)
    this.showDeleteSuccess();
  }
}
