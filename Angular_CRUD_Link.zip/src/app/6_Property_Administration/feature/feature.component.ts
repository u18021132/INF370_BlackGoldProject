import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

@Component({
  selector: 'app-feature',
  templateUrl: './feature.component.html',
  styleUrls: ['./feature.component.scss']
})

export class FeatureComponent implements OnInit {
  public features;
  public displaySuccess: boolean = false;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  // @Input('showTitle') 
  // get showTitle(): boolean {
  //   return this.displaySuccess;
  // }
  // set showTitle(value: boolean) {
  //   this.displaySuccess = "" + value !== "true";
  // }

  showAddSuccess() {
    this.toastr.success('Feature added successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showUpdateSuccess() {
    this.toastr.success('Feature updated successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showDeleteSuccess() {
    this.toastr.success('Feature deleted successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
    this.features = await this.service.Get('/feature');
    console.log(this.features);
  }

  async add(){

  }

  async delete(/*id*/){

  }

  async update(/*id*/){

  }

}
