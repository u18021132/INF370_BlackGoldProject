import { Component, OnInit } from '@angular/core';
import { HttpClient }  from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../../environments/api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  token: any;
  email:any;
  password:any;
  constructor(private service: ApiService, private http: HttpClient, private router: Router, private route:ActivatedRoute) { }

  ngOnInit(): void {
    if (localStorage.getItem("37y7ffheu73")){
      this.router.navigate([""])
  }
}

async Login(){
  this.token = await this.service.Login(`/user?email=${this.email}&password=${this.password}`)
  //console.log(this.token);
  localStorage.setItem("37y7ffheu73", this.token.token)
  this.router.navigate([""])
}

}
