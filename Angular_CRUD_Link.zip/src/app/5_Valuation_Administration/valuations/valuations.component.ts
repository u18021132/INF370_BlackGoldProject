import { Component, OnInit } from '@angular/core';

//added imports:
import {ApiService} from '../../../environments/api.service';
import {HttpClient}  from '@angular/common/http';
import { Router } from '@angular/router';

import { ToastrService } from 'ngx-toastr';
import { timer } from 'rxjs';

@Component({
  selector: 'app-valuations',
  templateUrl: './valuations.component.html',
  styleUrls: ['./valuations.component.scss']
})

export class ValuationsComponent implements OnInit {
  public valuations;

  constructor(private service: ApiService, private http: HttpClient, private router: Router, private toastr: ToastrService) { }

  showCaptureSuccess() {
    this.toastr.success('Valuation captured successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  showAssignSuccess() {
    this.toastr.success('Valuer assigned to valuation successfully', "", {
      timeOut: 1000,
    });
    setTimeout(location.reload.bind(location), 1000);
  }

  async ngOnInit() {
    this.valuations = await this.service.Get('/valuation');
    console.log(this.valuations);
  }

  async capture(){

  }

  async assign(){

  }

}
