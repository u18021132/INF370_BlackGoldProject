import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
url = 'https://localhost:44373/api';
  constructor(private http: HttpClient) { }
  headers = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }


  //Read
  public async Get(endpoint: string){
    let response = await this.http.get(`${this.url}${endpoint}`).toPromise();
    return response;
  }

  //Add
  public async Post(endpoint: string, body?: any) {
    if (body) {
      let response = await this.http.post(`${this.url}${endpoint}`, body, this.headers).toPromise();
      return response;
    }
    else {
      let response = await this.http.post(`${this.url}${endpoint}`, null).toPromise();
      return response;
    }
  }

  //Update
  public async Patch(endpoint: string, body?: any) {
    if (body) {
      let response = await this.http.patch(`${this.url}${endpoint}`, body, this.headers).toPromise();
      return response;
    }
    else {
      let response = await this.http.patch(`${this.url}${endpoint}`, null).toPromise();
      return response;
    }
  }

  //Delete
  public async Delete(endpoint: string) {
    let response = await this.http.delete(`${this.url}${endpoint}`).toPromise();
    return response;
  }

//Login
public async Login(endpoint: string, body?: any) {
  if (body) {
    let response = await this.http.post(`${this.url}${endpoint}`, body, this.headers).toPromise();
    return response;
  }
  else {
    let response = await this.http.post(`${this.url}${endpoint}`, null).toPromise();
    return response;
  }
}


}
